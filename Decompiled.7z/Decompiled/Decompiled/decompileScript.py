import os
import getpass
import subprocess
import shutil
 
current_file_path = os.getcwd()


for path in os.listdir(current_file_path):
    # check if current path is a file
    if path.endswith('.apk'):
        command = ["apktool", "d"]
        command.append(path)
        subprocess.Popen(command, shell = True)